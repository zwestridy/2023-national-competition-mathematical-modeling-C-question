import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.mlab as mlab
import matplotlib
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')
plt.rcParams['font.sans-serif'] = ['Simhei']
matplotlib.rcParams['axes.unicode_minus'] =False

df1 = pd.read_excel(r"C:\Users\admin\Desktop\数学建模\建模\C题\copy1.xlsx" )
df2 = pd.read_excel(r"C:\Users\admin\Desktop\数学建模\建模\C题\copy2.xlsx")
df3 = pd.read_excel(r"C:\Users\admin\Desktop\数学建模\建模\C题\copy3.xlsx")
df4 = pd.read_excel(r"C:\Users\admin\Desktop\数学建模\建模\C题\copy4.xlsx")
df44 = pd.read_excel(r"C:\Users\admin\Desktop\123.xlsx")
#汇总附件1和附件2 包含各种单品的流水信息
merge_data = pd.merge(df1, df2, on='单品编码', how='left')
#获取按品类计算的销售量
sale_catagory = merge_data.groupby("分类名称")['销量(千克)'].sum().sort_values(ascending=False)

#绘制箱线图
data1= merge_data[(merge_data.分类名称=='花叶类')& (merge_data['销量(千克)']<=5) &(merge_data['销量(千克)']>=0)]['销量(千克)']
data2= merge_data[(merge_data.分类名称=='辣椒类')& (merge_data['销量(千克)']<=5)&(merge_data['销量(千克)']>=0)]['销量(千克)']
data3= merge_data[(merge_data.分类名称=='食用菌')& (merge_data['销量(千克)']<=5)&(merge_data['销量(千克)']>=0)]['销量(千克)']
data4= merge_data[(merge_data.分类名称=='花菜类')& (merge_data['销量(千克)']<=5)&(merge_data['销量(千克)']>=0)]['销量(千克)']
data5= merge_data[(merge_data.分类名称=='水生根茎类')& (merge_data['销量(千克)']<=5)&(merge_data['销量(千克)']>=0)]['销量(千克)']
data6= merge_data[(merge_data.分类名称=='茄类')& (merge_data['销量(千克)']<=5)&(merge_data['销量(千克)']>=0)]['销量(千克)']


plt.figure(figsize=(12,8))
# plt.boxplot(data1,labels=['花叶类'],
#             whis=2,flierprops={'marker':'o'})

plt.boxplot([data1,data2,data3,data4,data5,data6],labels=['花叶类','辣椒类','食用菌','花菜类','水生根茎类','茄类'],
            whis=2,flierprops={'marker':'o'},patch_artist=True,boxprops={'color':'k','facecolor':'#9999ff'})
plt.title('各品类销售量箱线图',fontsize=20)
plt.show()

#每一类的热力图及六类之间的热力图

pivot_cata = pd.pivot_table(merge_data,index="销售日期", columns="分类名称",values="销量(千克)",aggfunc=np.sum).fillna(0)

cor_cata=pivot_cata.corr()


plt.figure(figsize=(12,8))
sns.heatmap(cor_cata,cmap='coolwarm',annot=True,annot_kws={'size':20,'weight':'bold'},linewidths=.3,vmin=-1,vmax=1)
plt.title("各品类的相关系数（热力图）",fontsize=21)
plt.xticks(fontsize=12)
plt.yticks(fontsize=12)
plt.xlabel('分类名称',fontsize=16)
plt.ylabel('分类名称',fontsize=16)
plt.show()


# 六个类各自单品热力图
cata1 = sale_catagory.index[0]
cata2 = sale_catagory.index[1]
cata3 = sale_catagory.index[2]
cata4 = sale_catagory.index[3]
cata5 = sale_catagory.index[4]
cata6 = sale_catagory.index[5]

cata1_data = merge_data[merge_data.分类名称==cata1]
cata2_data = merge_data[merge_data.分类名称==cata2]
cata3_data = merge_data[merge_data.分类名称==cata3]
cata4_data = merge_data[merge_data.分类名称==cata4]
cata5_data = merge_data[merge_data.分类名称==cata5]
cata6_data = merge_data[merge_data.分类名称==cata6]

pivot_cata1 = pd.pivot_table(cata1_data,index="销售日期", columns='单品名称',values="销量(千克)",aggfunc=np.sum).fillna(0)
pivot_cata2 = pd.pivot_table(cata2_data,index="销售日期", columns="单品名称",values="销量(千克)",aggfunc=np.sum).fillna(0)
pivot_cata3 = pd.pivot_table(cata3_data,index="销售日期", columns="单品名称",values="销量(千克)",aggfunc=np.sum).fillna(0)
pivot_cata4 = pd.pivot_table(cata4_data,index="销售日期", columns="单品名称",values="销量(千克)",aggfunc=np.sum).fillna(0)
pivot_cata5 = pd.pivot_table(cata5_data,index="销售日期", columns="单品名称",values="销量(千克)",aggfunc=np.sum).fillna(0)
pivot_cata6 = pd.pivot_table(cata6_data,index="销售日期", columns="单品名称",values="销量(千克)",aggfunc=np.sum).fillna(0)

cor_cata1=pivot_cata1.corr()
cor_cata2=pivot_cata2.corr()
cor_cata3=pivot_cata3.corr()
cor_cata4=pivot_cata4.corr()
cor_cata5=pivot_cata5.corr()
cor_cata6=pivot_cata6.corr()


fig,axs =plt.subplots(2,3,figsize=(12,8))

sns.heatmap(cor_cata1,cmap='coolwarm',linewidths=.3,vmin=-1,vmax=1,ax=axs[0,0],annot=False)
axs[0,0].set_title('花叶类')
sns.heatmap(cor_cata2,cmap='coolwarm',linewidths=.3,vmin=-1,vmax=1,ax=axs[0,1],annot=False)
axs[0,1].set_title('辣椒类')
sns.heatmap(cor_cata3,cmap='coolwarm',linewidths=.3,vmin=-1,vmax=1,ax=axs[0,2],annot=False)
axs[0,2].set_title('食用菌')
sns.heatmap(cor_cata4,cmap='coolwarm',linewidths=.3,vmin=-1,vmax=1,ax=axs[1,0],annot=False)
axs[1,0].set_title('花菜类')
sns.heatmap(cor_cata5,cmap='coolwarm',linewidths=.3,vmin=-1,vmax=1,ax=axs[1,1],annot=False)
axs[1,1].set_title('水生根茎类')
sns.heatmap(cor_cata6,cmap='coolwarm',linewidths=.3,vmin=-1,vmax=1,ax=axs[1,2],annot=False)
axs[1,2].set_title('茄类')

plt.tight_layout()
plt.show()


# 绘制批发价格随时间变化趋势
#汇总附件1和附件2 包含各种单品的流水信息
merge_data = pd.merge(df1, df2, on='单品编码', how='left')
#获取按品类计算的销售量
sale_catagory = merge_data.groupby("分类名称")['销量(千克)'].sum().sort_values(ascending=False)
# Merge attachment 3 (wholesale prices) with attachment 1 (product and category info)
pricing_data = pd.merge(df3, df1, on="单品编码", how="left")
cost_data = pd.merge(pricing_data,df44,on='单品编码',how='left')


# # Average wholesale price for each category in the past
# avg_wholesale_price = pricing_data.groupby('分类名称')['批发价格(元/千克)'].mean()
#
# Merge the average wholesale price with the loss rate from attachment 4
# cost_data = pd.merge(avg_wholesale_price, df4, left_on='分类名称', right_on='小分类名称', how="left")
# Calculate the cost per kg considering the loss rate
cost_data['cost_per_kg'] = cost_data['批发价格(元/千克)'] * (1 + cost_data['损耗率(%)'] / 100)

# # Extract the relevant columns
# cost_data1=cost_data[['小分类名称','平均损耗率(%)_小分类编码_不同值']]
# cost_data = cost_data[['小分类名称', 'cost_per_kg']]
# 按季节可视化
quarterly_sales = cost_data.resample('Q', on='日期')['cost_per_kg'].sum()
sales_quarter_catagory = cost_data[merge_data['销售类型'] == '销售'].groupby(['分类名称', pd.Grouper(key='日期', freq='Q')])['cost_per_kg'].sum()
fig, ax = plt.subplots(figsize=(10, 6))
for category in sales_quarter_catagory.index.levels[0]:
    ax.plot(sales_quarter_catagory.loc[category].index, sales_quarter_catagory.loc[category].values, label=category)
ax.legend()
ax.set_xlabel('季度',fontsize=18)
ax.set_ylabel('各蔬菜品类批发价（元）',fontsize=18)
ax.set_title('蔬菜各品类批发价随时间变化折线图',fontsize=24)
plt.show()


# 获取各单品加权销售额
#汇总
merge_data = pd.merge(df1, df2, on='单品编码', how='left')

merge_price = pd.merge(merge_data, df3,left_on=["单品编码", "销售日期"], right_on=["单品编码", "日期"], how="left")
# 计算利润
merge_price["销售金额"] = merge_price["销售单价(元/千克)"] * merge_price["销量(千克)"]
merge_price["利润"] = merge_price["销售金额"] - (merge_price["销量(千克)"] * merge_price["批发价格(元/千克)"])

df = merge_price[ merge_price['销量(千克)'] < 10]
df = df.rename(columns={'分类名称': 'class', '销售日期': 'Date', '单品名称' :'categories','销量(千克)': 'Sales', '销售单价(元/千克)': 'Price','销售金额':'total','利润':'profits','损耗率(%)':'loss'})
df4 = df4.rename(columns={'小分类编码':'分类编码','小分类名称':'分类名称','平均损耗率(%)_小分类编码_不同值':'平均损耗率'})

category_price_sum = df.groupby(['class','categories'])['Sales'].sum()
class_price_sum = df.groupby('class')['Sales'].sum()
category_total_sum=df.groupby(['class','categories'])['total'].sum()

category_price_sum = category_price_sum.reset_index()
class_price_sum  = class_price_sum.reset_index()
category_total_sum = category_total_sum.reset_index()

classes = df['class'].unique()
class_data = {}
for class_ in classes:
    categories = category_price_sum.loc[category_price_sum['class'] == class_, 'categories'].values
    sales_datas = category_price_sum.loc[category_price_sum['class'] == class_, 'Sales'].values
    rate = sales_datas / class_price_sum.loc[class_price_sum['class'] == class_,'Sales'].values
    price = category_total_sum.loc[category_total_sum['class']==class_,'total'].values
    total = rate * price

    data = pd.DataFrame({'catagories':class_,'products':categories,'kg':sales_datas,'rate':rate,'单品金额':price,'加权后销售价':total})
    class_data[class_] = data

# rate_df = pd.DataFrame(class_data)

for class_ in classes:
    print(class_,'\n',class_data[class_].groupby('catagories')['加权后销售价'].sum())



#对时间重构数据
ts_data = merge_data.groupby(['销售日期', '分类名称'])['销量(千克)'].sum().reset_index()
ts_data = ts_data.pivot(index='销售日期', columns='分类名称', values='销量(千克)').fillna(0)


df1 = pd.read_excel(r"C:\Users\admin\Desktop\数学建模\建模\C题\copy1.xlsx" )
df2 = pd.read_excel(r"C:\Users\admin\Desktop\数学建模\建模\C题\copy2.xlsx")
df3 = pd.read_excel(r"C:\Users\admin\Desktop\数学建模\建模\C题\copy3.xlsx")
df4 = pd.read_excel(r"C:\Users\admin\Desktop\数学建模\建模\C题\copy4.xlsx")

#汇总附件1和附件2 包含各种单品的流水信息
merge_data = pd.merge(df1, df2, on='单品编码', how='left')
#获取按品类计算的销售量
sale_catagory = merge_data.groupby("分类名称")['销量(千克)'].sum().sort_values(ascending=False)

#按季节可视化
quarterly_sales = merge_data.resample('Q', on='销售日期')['销量(千克)'].sum()
sales_quarter_catagory = merge_data[merge_data['销售类型'] == '销售'].groupby(['分类名称', pd.Grouper(key='销售日期', freq='Q')])['销量(千克)'].sum()
fig, ax = plt.subplots(figsize=(10, 6))
for category in sales_quarter_catagory.index.levels[0]:
    ax.plot(sales_quarter_catagory.loc[category].index, sales_quarter_catagory.loc[category].values, label=category)
ax.legend()
ax.set_xlabel('季度')
ax.set_ylabel('销售量（千克）')
ax.set_title('蔬菜各品类销售量变化趋势')
plt.show()


#汇总附件1和附件2 包含各种单品的流水信息
merge_data = pd.merge(df1, df2, on='单品编码', how='left')
#获取按品类计算的销售量
sale_catagory = merge_data.groupby("分类名称")['销量(千克)'].sum().sort_values(ascending=False)

# #绘制品类与销量的柱状图
plt.figure(figsize=(10, 6))
x = sale_catagory.index
y = sale_catagory.values
plt.bar(x,y)
# figure1 = sns.barplot(x = sale_catagory.index,y = sale_catagory.values,data=cata_sales )

for a,b in zip(x,y):
    plt.text(a,b+10,b,ha='center',va='bottom',fontsize=12)
plt.title("不同品类的总销量",fontsize = 30)
plt.ylabel("总销量(kg)",fontsize = 24)
plt.tick_params(labelsize=18)
plt.show()

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.mlab as mlab
import matplotlib
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')
plt.rcParams['font.sans-serif'] = ['Simhei']
matplotlib.rcParams['axes.unicode_minus'] =False

df1 = pd.read_excel(r"C:\Users\admin\Desktop\数学建模\建模\C题\copy1.xlsx" )
df2 = pd.read_excel(r"C:\Users\admin\Desktop\数学建模\建模\C题\copy2.xlsx")
df3 = pd.read_excel(r"C:\Users\admin\Desktop\数学建模\建模\C题\copy3.xlsx")
df4 = pd.read_excel(r"C:\Users\admin\Desktop\数学建模\建模\C题\copy4.xlsx")

#汇总
merge_data = pd.merge(df1, df2, on='单品编码', how='left')

merge_price = pd.merge(merge_data, df3,left_on=["单品编码", "销售日期"], right_on=["单品编码", "日期"], how="left")
# 计算利润
merge_price["销售金额"] = merge_price["销售单价(元/千克)"] * merge_price["销量(千克)"]
merge_price["利润"] = merge_price["销售金额"] - (merge_price["销量(千克)"] * merge_price["批发价格(元/千克)"])

df = merge_price[ merge_price['销量(千克)'] < 10]
df = df.rename(columns={'分类名称': 'class', '销售日期': 'Date', '单品名称' :'categories','销量(千克)': 'Sales', '销售单价(元/千克)': 'Price','销售金额':'total','利润':'profits','损耗率(%)':'loss'})
df4 = df4.rename(columns={'小分类编码':'分类编码','小分类名称':'分类名称','平均损耗率(%)_小分类编码_不同值':'平均损耗率'})



category_price_sum = df.groupby(['class','categories'])['Sales'].sum()
class_price_sum = df.groupby('class')['Sales'].sum()
category_total_sum=df.groupby(['class','categories'])['total'].sum()

category_price_sum = category_price_sum.reset_index()
class_price_sum  = class_price_sum.reset_index()
category_total_sum = category_total_sum.reset_index()

classes = df['class'].unique()
class_data = {}
for class_ in classes:
    categories = category_price_sum.loc[category_price_sum['class'] == class_, 'categories'].values
    sales_datas = category_price_sum.loc[category_price_sum['class'] == class_, 'Sales'].values
    rate = sales_datas / class_price_sum.loc[class_price_sum['class'] == class_,'Sales'].values
    price = category_total_sum.loc[category_total_sum['class']==class_,'total'].values
    total = rate * price

    data = pd.DataFrame({'分类名称':class_,'单品名称':categories,'销量(千克)':sales_datas,'rate':rate,'销售金额':price,'加权后销售价':total})
    class_data[class_] = data

class_data['花叶类'].to_excel('花叶类信息表.xlsx')
class_data['辣椒类'].to_excel('辣椒类信息表.xlsx')
class_data['茄类'].to_excel('茄类信息表.xlsx')
class_data['水生根茎类'].to_excel('水生根茎类信息表.xlsx')
class_data['花菜类'].to_excel('花菜类信息表.xlsx')
class_data['食用菌'].to_excel('食用菌信息表.xlsx')

#对时间重构数据
ts_data = merge_data.groupby(['销售日期', '分类名称'])['销量(千克)'].sum().reset_index()
ts_data2 =merge_price.groupby(['销售日期', '分类名称'])['销售金额'].sum().reset_index()
pivot_ts=pd.pivot_table(ts_data,index='销售日期', columns='分类名称', values='销量(千克)').fillna(0)
pivot_ts2=pd.pivot_table(ts_data2,index='销售日期', columns='分类名称', values='销售金额').fillna(0)

pivot_ts2.to_excel('时间销量金额表.xlsx')
x=pivot_ts['花叶类'].values
y=pivot_ts2['花叶类'].values
plt.figure(figsize=(10,8))
plt.scatter(x,y)
plt.legend()
plt.title('销售量与加权后销售价散点图',fontsize=20)
plt.xlabel('销售量(kg)',fontsize=16)
plt.ylabel('加权后销售价(元)',fontsize=16)
plt.show()

# 线性回归
# def forecast_sales(category):
#     category_data = daily_sales[daily_sales['分类名称'] == category].reset_index(drop=True)
#     category_data['day_num'] = np.arange(len(category_data))
#
#     X = category_data[['day_num']]
#     y = category_data['销量(千克)']
#
#     # Split the data into training and testing sets (80% train, 20% test)
#     X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, shuffle=False)
#
#     # Train a linear regression model
#     model = LinearRegression()
#     model.fit(X_train, y_train)
#
#     # Predict the sales for the test set
#     y_pred = model.predict(X_test)
#
#     # Calculate the mean squared error of the prediction
#     mse = mean_squared_error(y_test, y_pred)
#
#     # Predict the sales for the next 7 days
#     next_7_days = np.array([max(category_data['day_num']) + i for i in range(1, 8)]).reshape(-1, 1)
#     future_forecast = model.predict(next_7_days)
#
#     return future_forecast, mse
#
# forecasts = {}
# errors = {} #均方误差
# for category in daily_sales['分类名称'].unique():
#     forecasts[category], errors[category] = forecast_sales(category)
#
# # Re-generating the day_num column for the entire daily_sales DataFrame  生成新的一列
# daily_sales['day_num'] = daily_sales.groupby('分类名称').cumcount()
#
# # Visualization based on forecasts and errors
#
# # Plotting sales forecast vs actual sales for each category  实际销售与预测销售
# plt.figure(figsize=(16, 8))
#
# for category in daily_sales['分类名称'].unique():
#     category_data = daily_sales[daily_sales['分类名称'] == category].reset_index(drop=True)
#     X = category_data[['day_num']]
#     y = category_data['销量(千克)']
#     _, X_test, _, y_test = train_test_split(X, y, test_size=0.2, random_state=42, shuffle=False)
#
#     # Plotting the actual test data
#     plt.scatter(X_test.day_num, y_test, label=f"Actual {category}", marker='x')
#
#     # Plotting the forecasted data
#     next_7_days = np.array([max(category_data['day_num']) + i for i in range(1, 8)])
#     plt.plot(next_7_days, forecasts[category], label=f"Forecast {category}")

plt.title('销售预测与实际销售')
plt.xlabel('时间')
plt.ylabel('销量 (kg)')
plt.legend(loc='upper left')
plt.grid(True, which='both', linestyle='--', linewidth=0.5)
plt.tight_layout()
plt.show()

# # Plotting the Mean Squared Error for each category
# plt.figure(figsize=(10, 6))
# plt.bar(errors.keys(), errors.values(), color='skyblue')
# plt.title('每个类别的MSE')
# plt.xlabel('类别')
# plt.ylabel('MSE')
# plt.grid(axis='y', linestyle='--', linewidth=0.5)
# plt.tight_layout()
# plt.show()

# 按品类计算利润和销售量
category_profit = merge_price.groupby("分类名称")["利润"].sum()
category_sales_volume = merge_price.groupby("分类名称")["销量(千克)"].sum()

# 绘制各品类销售量和利润关系图
plt.figure(figsize=(12, 6))
sns.scatterplot(x=category_sales_volume, y=category_profit, hue=category_profit.index, s=100)
plt.title("绘制蔬菜各品类销售量和利润散点图",fontsize=20)
plt.xlabel("各品类总销售量（kg）",fontsize=16)
plt.ylabel("总利润 (元)",fontsize=16)

plt.legend(title="蔬菜品类", bbox_to_anchor=(1.05, 1), loc='upper left')
plt.tight_layout()
plt.show()

# Group by '单品名称' and get the average sales for the entire dataset
avg_sales_overall = merge_data.groupby('单品名称')['销量(千克)'].mean().reset_index()

# Use this as the forecasted sales for July 1st
forecasted_sales_july1_overall = avg_sales_overall.copy()
forecasted_sales_july1_overall.rename(columns={'销量(千克)': '预测销量_7月1日'}, inplace=True)

forecasted_sales_july1_overall.head()

# Merge forecasted sales with pricing and loss rate data
product_cost_data = pd.merge(forecasted_sales_july1_overall, pricing_data, on="单品名称", how="left")
product_cost_data = pd.merge(product_cost_data, df4, left_on='分类名称', right_on='小分类名称', how="left")

# Calculate the cost per kg considering the loss rate
product_cost_data['cost_per_kg'] = product_cost_data['批发价格(元/千克)'] * (1 + product_cost_data['平均损耗率(%)_小分类编码_不同值'] / 100)

product_cost_data[['单品名称', '预测销量_7月1日', '批发价格(元/千克)', '平均损耗率(%)_小分类编码_不同值', 'cost_per_kg']].head()


# Define a function to set the markup rate based on forecasted sales volume for individual products
def determine_product_markup_rate(sales_forecast):
    if sales_forecast < 0.5:
        return 1.5  # 150% markup for low volume items
    elif sales_forecast < 1:
        return 1.3  # 130% markup for medium volume items
    else:
        return 1.2  # 120% markup for high volume items

# Calculate the expected profit for each product
product_cost_data['markup_rate'] = product_cost_data['预测销量_7月1日'].apply(determine_product_markup_rate)
product_cost_data['expected_price'] = product_cost_data['cost_per_kg'] * product_cost_data['markup_rate']
product_cost_data['expected_profit_per_kg'] = product_cost_data['expected_price'] - product_cost_data['cost_per_kg']
product_cost_data['total_expected_profit'] = product_cost_data['expected_profit_per_kg'] * product_cost_data['预测销量_7月1日']

# Sort the products based on the expected profit
sorted_products = product_cost_data.sort_values(by='total_expected_profit', ascending=False).drop_duplicates(subset='单品名称')

sorted_products[['单品名称', '预测销量_7月1日', 'cost_per_kg', 'expected_price', 'total_expected_profit']].head()

# Select top 27-33 products based on the expected profit
selected_products = sorted_products.head(33)

# Calculate the total expected profit for these selected products
total_expected_profit = selected_products['total_expected_profit'].sum()

selected_products[['单品名称', '预测销量_7月1日', 'cost_per_kg', 'expected_price', 'total_expected_profit']], total_expected_profit


# Set the replenishment volume for each selected product
min_display_volume = 2.5
selected_products['replenishment_volume'] = selected_products['预测销量_7月1日'].apply(lambda x: max(x, min_display_volume))

# Display the selected products, their expected price and replenishment volume
selected_products_final = selected_products[['单品名称', 'expected_price', 'replenishment_volume']]
selected_products_final
selected_products_final.to_excel(r"C:\Users\86136\Desktop\selected_products_final.xlsx", index=False)









